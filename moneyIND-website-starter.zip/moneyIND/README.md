# moneyIND starter

A responsive mobile-first income dashboard inspired by the supplied RichIND screenshot.

## Included
- Mobile-first Hindi dashboard and gradient income cards
- Firebase Phone OTP login integration (requires your own Firebase project)
- Firestore read path for user-specific income records
- Admin panel UI and admin role check
- Starter Firestore security rules that prevent browser-side income manipulation

## Important limitation
This is a starter project, not a deployed production service. The admin form intentionally does **not** create records yet: secure recipient lookup and record creation should be implemented in a Firebase Cloud Function or trusted server using the Firebase Admin SDK. Do not let the browser directly assign roles or write income figures.

## Setup
1. Create a Firebase project at https://console.firebase.google.com/
2. Enable **Authentication → Phone** and create a **Cloud Firestore** database.
3. In Project settings → General → Your apps, register a Web app and copy its config into `app.js`, replacing all `PASTE_...` values.
4. Add your deployment hostname to Authentication → Settings → Authorized domains.
5. Publish `firestore.rules` from Firebase Console → Firestore → Rules.
6. Create a `users` document whose ID is your verified Firebase Auth UID and fields are `{ "role": "admin" }`. Do this manually from the Firebase Console. Never expose service account credentials.
7. Deploy the static files to Firebase Hosting, Netlify, or another HTTPS host.
8. Add a trusted Cloud Function to let admins resolve a verified phone number to a UID and create a record. Validate amount, recipient, admin role, and audit metadata server-side.

## Data model
`users/{uid}`:
```json
{ "role": "admin" }
```

`incomeRecords/{recordId}`:
```json
{
  "uid": "recipient Firebase Auth UID",
  "amount": 500,
  "type": "income",
  "note": "Bonus",
  "createdAt": "Firestore server timestamp",
  "createdBy": "admin UID"
}
```

## Before real users
- Add privacy policy and terms, consent for SMS OTP, support contact, abuse controls and rate limits.
- Test Firestore rules using Firebase Emulator.
- Add audit logs and a review process for adjustments.
- Display only verified, genuine income records; do not imply demo numbers are real earnings.
