import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, addDoc, query, where, orderBy, getDocs, serverTimestamp, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

/*
  SETUP:
  1) Create a Firebase project and enable Authentication > Phone.
  2) Create Firestore Database.
  3) Paste your Firebase web config below.
  4) Add your hosted domain to Firebase Authentication authorized domains.
  5) Set admin users in Firestore: users/{UID} with { role: "admin" }.
  6) Publish firestore.rules. Never put service-account credentials in this file.
*/
const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
const configured = !Object.values(firebaseConfig).some(v => v.startsWith("PASTE_"));
const $ = id => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
let auth, db, confirmationResult, recaptcha, currentUser, incomeRecords = [], isAdmin = false;

function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),3500)}
function money(n){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(n||0))}
function showMessage(id,msg){$(id).textContent=msg}
function dateOf(r){return r.createdAt?.toDate ? r.createdAt.toDate() : (r.createdAt ? new Date(r.createdAt) : new Date(0))}
function sum(records){return records.reduce((s,r)=>s+Number(r.amount||0),0)}
function startOfDay(d){const x=new Date(d);x.setHours(0,0,0,0);return x}
function paintDashboard(){
 const now=new Date(), today=startOfDay(now), week=new Date(today);week.setDate(week.getDate()-6);const month=new Date(today);month.setDate(month.getDate()-29);
 $("todayIncome").textContent=money(sum(incomeRecords.filter(r=>dateOf(r)>=today)));
 $("weekIncome").textContent=money(sum(incomeRecords.filter(r=>dateOf(r)>=week)));
 $("monthIncome").textContent=money(sum(incomeRecords.filter(r=>dateOf(r)>=month)));
 $("allIncome").textContent=money(sum(incomeRecords));
 $("passiveIncome").textContent=money(sum(incomeRecords.filter(r=>r.type==="passive")));
 const list=$("records");list.innerHTML="";
 if(!incomeRecords.length){list.innerHTML='<p class="muted">अभी कोई कमाई रिकॉर्ड उपलब्ध नहीं है।</p>';return}
 incomeRecords.slice(0,12).forEach(r=>{const el=document.createElement("div");el.className="record";const left=document.createElement("div");const title=document.createElement("div");title.className="record-title";title.textContent=r.note|| (r.type==="passive"?"Passive Income":"Income");const sub=document.createElement("div");sub.className="record-sub";sub.textContent=`${dateOf(r).getTime()?dateOf(r).toLocaleString("en-IN"):"Date unavailable"} · ${r.type==="passive"?"Passive":"Income"}`;left.append(title,sub);const amt=document.createElement("div");amt.className="record-amount";amt.textContent="+"+money(r.amount);el.append(left,amt);list.append(el)});
}
async function loadRecords(){
 if(!db||!currentUser)return;
 try{const q=query(collection(db,"incomeRecords"),where("uid","==",currentUser.uid),orderBy("createdAt","desc"));const snap=await getDocs(q);incomeRecords=snap.docs.map(d=>({id:d.id,...d.data()}));paintDashboard()}
 catch(e){console.error(e);$("records").innerHTML='<p class="muted">रिकॉर्ड लोड नहीं हो सके। Firestore rules और index जाँचें।</p>'}
}
async function checkAdmin(){
 isAdmin=false;
 try{const s=await getDoc(doc(db,"users",currentUser.uid));isAdmin=s.exists()&&s.data().role==="admin"}catch(e){console.warn(e)}
 $("adminPanel").classList.toggle("hidden",!isAdmin);
}
function showDashboard(user){
 $("loginPanel").classList.add("hidden");$("dashboard").classList.remove("hidden");
 $("userBadge").textContent=user.phoneNumber||"Logged in";$("welcomeName").textContent=user.phoneNumber||"User";
}
function setupFirebase(){
 const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
 onAuthStateChanged(auth,async user=>{
   currentUser=user;
   if(user){showDashboard(user);await checkAdmin();await loadRecords()}
   else{$("dashboard").classList.add("hidden");$("loginPanel").classList.remove("hidden");$("userBadge").textContent="Guest"}
 });
}
$("sendOtp").addEventListener("click",async()=>{
 const phone=$("phone").value.replace(/\D/g,"");
 if(!/^[6-9]\d{9}$/.test(phone)){showMessage("loginMessage","कृपया सही 10 अंकों का भारतीय मोबाइल नंबर डालें।");return}
 if(!configured){showMessage("loginMessage","पहले app.js में Firebase configuration भरें। अभी लाइव OTP सक्रिय नहीं है।");return}
 try{
   $("sendOtp").disabled=true;
   if(!recaptcha)recaptcha=new RecaptchaVerifier(auth,"recaptcha-container",{size:"normal"});
   confirmationResult=await signInWithPhoneNumber(auth,"+91"+phone,recaptcha);
   $("otpArea").classList.remove("hidden");showMessage("loginMessage","OTP भेज दिया गया है। SMS देखें।");
 }catch(e){console.error(e);showMessage("loginMessage",e.message||"OTP नहीं भेजा जा सका।")}
 finally{$("sendOtp").disabled=false}
});
$("verifyOtp").addEventListener("click",async()=>{
 const otp=$("otp").value.trim();if(!confirmationResult||!/^\d{6}$/.test(otp)){showMessage("loginMessage","6 अंकों का सही OTP डालें।");return}
 try{await confirmationResult.confirm(otp);showMessage("loginMessage","लॉगिन सफल।")}
 catch(e){showMessage("loginMessage","OTP सत्यापित नहीं हुआ। दोबारा जाँचें।")}
});
$("logoutBtn").addEventListener("click",()=>auth&&signOut(auth));
$("refreshBtn").addEventListener("click",loadRecords);
$("menuBtn").addEventListener("click",()=>{if(!currentUser)toast("लॉगिन करने के बाद आपका डैशबोर्ड दिखेगा।");else document.getElementById(isAdmin?"adminPanel":"records").scrollIntoView({behavior:"smooth"})});
$("incomeForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!isAdmin||!db){showMessage("adminMessage","केवल अधिकृत एडमिन रिकॉर्ड जोड़ सकता है।");return}
 const phone=$("targetPhone").value.trim().replace(/\s/g,"");const amount=Number($("incomeAmount").value);const type=$("incomeType").value;const note=$("incomeNote").value.trim();
 if(!phone.startsWith("+")||!Number.isFinite(amount)||amount<=0){showMessage("adminMessage","देश कोड सहित मोबाइल नंबर और सही रकम डालें।");return}
 try{
   // Resolve the recipient by their verified phone number through a controlled backend in production.
   // Client-only admin should not be allowed to look up arbitrary users; use a server/Cloud Function for this.
   showMessage("adminMessage","इस starter में सुरक्षित recipient lookup के लिए Cloud Function जोड़ना आवश्यक है। रिकॉर्ड नहीं जोड़ा गया।");
 }catch(err){console.error(err);showMessage("adminMessage","रिकॉर्ड जोड़ने में समस्या हुई।")}
});
document.querySelectorAll("[data-detail]").forEach(btn=>btn.addEventListener("click",()=>{
 const key=btn.dataset.detail, now=new Date(), today=startOfDay(now), week=new Date(today), month=new Date(today);week.setDate(week.getDate()-6);month.setDate(month.getDate()-29);
 const filters={today:r=>dateOf(r)>=today,week:r=>dateOf(r)>=week,month:r=>dateOf(r)>=month,all:r=>true,passive:r=>r.type==="passive"};
 const titles={today:"Today's Income",week:"7 Days Income",month:"30 Days Income",all:"All Time Income",passive:"Passive Income"};
 const arr=incomeRecords.filter(filters[key]);$("detailTitle").textContent=titles[key];$("detailBody").innerHTML="";
 const total=document.createElement("h3");total.textContent="Total: "+money(sum(arr));$("detailBody").append(total);
 if(!arr.length){const p=document.createElement("p");p.className="muted";p.textContent="इस अवधि में कोई रिकॉर्ड नहीं है।";$("detailBody").append(p)}
 arr.slice(0,30).forEach(r=>{const p=document.createElement("p");p.textContent=`${dateOf(r).toLocaleDateString("en-IN")} — ${r.note||r.type}: ${money(r.amount)}`;$("detailBody").append(p)});
 $("detailDialog").showModal();
}));
$("closeDialog").addEventListener("click",()=>$("detailDialog").close());
if(configured)setupFirebase();
else{
 $("loginMessage").textContent="Demo setup: Firebase credentials जोड़ने के बाद ही वास्तविक OTP और खाते काम करेंगे।";
 $("records").textContent="Firebase सेटअप होने पर यहाँ वास्तविक रिकॉर्ड आएँगे।";
}
